const crypto = require('crypto');
const algorithm = 'aes-256-cbc';
// const key = crypto.randomBytes(32);
const iv = crypto.randomBytes(16);
const key = "npTIt9bIG6sFR3zJA5xetuYTLTbqwhCA";
//const iv = "npTIt9bIG6sFR3zJ";

function encrypt(text) {
 let cipher = crypto.createCipheriv(algorithm, Buffer.from(key), iv);
 let encrypted = cipher.update(text);
 encrypted = Buffer.concat([encrypted, cipher.final()]);
 return { iv: iv.toString('hex'), encryptedData: encrypted.toString('hex') };
}

function decrypt(text) {
 let iv = Buffer.from(text.iv, 'hex');
 let encryptedText = Buffer.from(text.encryptedData, 'hex');
 let decipher = crypto.createDecipheriv(algorithm, Buffer.from(key), iv);
 let decrypted = decipher.update(encryptedText);
 decrypted = Buffer.concat([decrypted, decipher.final()]);
 return decrypted.toString();
}


// {"application":"DBG","clientCode":"10116241"}
// {"FilterValue":"10116241","FilterValue2":"NSE|CAPITAL","Action":"BankDetails","Application":"DBG"}
// {"clientCode":"10116241","vpa":"np58845@okhdfcbank","application":"DBG"}
// {"from":"2022-11-10","to":"2022-11-10","clientCode":"10116241","application":"DBG","ac":"2"}
// {"upiId":"","clientCode":"10116241","name":"AMIT RAMDAS MORADE","mobileNo":"8652046439","email":"kirand@rupeeseed.com","bankName":"STATE BANK OF INDIA","bankAccNo":"395010100333979","ifsc":"SBIN0001888","amount":"2","mode":"upi","application":"DBG"}
// {"referenceNo":"7093ff758fc55289","application":"DBG","clientCode":"10116241"}
// {"clientCode":"10116241","application":"DBG"}

//Encryption
var application = encrypt("DBG");
var clintCode=encrypt("10116241"); 
var FilterValue=encrypt("10116241");
var FilterValue2=encrypt("NSE|CAPITAL");
var Action=encrypt("BankDetails");
var Application=encrypt("DBG");
var vpa=encrypt("np58845@okhdfcbank");
var from=encrypt("2022-11-10");
var to=encrypt("2022-11-10");
var ac=encrypt("2");
var upiId=encrypt("");
var name=encrypt("AMIT RAMDAS MORADE");
var mobileNo=encrypt("8652046439");
var email=encrypt("kirand@rupeeseed.com");
var referenceNo=encrypt("7093ff758fc55289");
var bankName=encrypt("STATE BANK OF INDIA");
var ifsc=encrypt("SBIN0001888");
var amount=encrypt("2");
var mode=encrypt("upi");


//Printing Encrypted value
console.log("application", application);
console.log("Application", Application);
console.log("clintCode", clintCode)
console.log("FilterValue", FilterValue);
console.log("FilterValue2", FilterValue2)
console.log("Action", Action);
console.log("vpa", vpa)
console.log("from", from);
console.log("to", to)
console.log("ac", ac);
console.log("upiId", upiId);
console.log("name", name);
console.log("mobileNo", mobileNo);
console.log("referenceNo", referenceNo);
console.log("amount", amount);
console.log("bankName", bankName);
console.log("email", email);
console.log("ifsc", ifsc);
console.log("mode", mode);

//printinf Decrypted values


console.log("application", decrypt(application));
console.log("Application", decrypt(Application));
console.log("clintCode", decrypt(clintCode))
console.log("FilterValue", decrypt(FilterValue));
console.log("FilterValue2", decrypt(FilterValue2))
console.log("Action", decrypt(Action));
console.log("vpa", decrypt(vpa))
console.log("from", decrypt(from));
console.log("to", decrypt(to))
console.log("ac", decrypt(ac));
console.log("upiId", decrypt(upiId));
console.log("name", decrypt(name));
console.log("mobileNo", decrypt(mobileNo));
console.log("referenceNo", decrypt(referenceNo));
console.log("amount", decrypt(amount));
console.log("bankName", decrypt(bankName));
console.log("email", decrypt(email));
console.log("ifsc", decrypt(ifsc));
console.log("mode", decrypt(mode));