const express = require("express");
const crypto = require("crypto");
var app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.get("/", (req, res) => {
    const encrypted="e224e90c7c33f0669515cb937f5a7c2abbd2a30b1238c7c31162be13b8b9393e3db8f1185c0ea0152bdbe16bd0dc415a";
    const  IV="b99bbbbeb8c8fcb3637baae36499f581";
    console.log(IV.length)
    const keyString = "npTIt9bIG6sFR3zJA5xetuYTLTbqwhCA";
    const key = crypto.createHash("sha256").update(keyString).digest();
    console.log({ IV: Buffer.from(IV, "hex").length, key: key.length });
    try { 
        const iv = Buffer.from(IV, "hex");
        const encryptedText = Buffer.from(encrypted, "hex");
        // "aes-256-cbc" is type of algorithm to use for decryption
        let decipher = crypto.createDecipheriv("aes-256-cbc", key, iv);
        let decrypted = decipher.update(encryptedText);
        decrypted = Buffer.concat([decrypted, decipher.final()]);
        // Original data gotten back after decryption and then parsed to JSON
        const obj = JSON.parse(decrypted.toString());
        res.send({ ...obj, fromBack: "Message decrypted successfully!" });
      } catch (err) {
        console.log(err.message);
      }
  res.send("Home Crypt Home");
});
// Decryption Handler

app.post("/decrypt", (req, res) => {
  const { encrypted, IV } = req.body;
  const keyString = "npTIt9bIG6sFR3zJA5xetuYTLTbqwhCA";
  const key = crypto.createHash("sha256").update(keyString).digest();
  console.log({ IV: Buffer.from(IV, "hex").length, key: key.length });

  try {
    const iv = Buffer.from(IV, "hex");
    const encryptedText = Buffer.from(encrypted, "hex");
    // "aes-256-cbc" is type of algorithm to use for decryption
    let decipher = crypto.createDecipheriv("aes-256-cbc", key, iv);
    let decrypted = decipher.update(encryptedText);
    decrypted = Buffer.concat([decrypted, decipher.final()]);
    // Original data gotten back after decryption and then parsed to JSON
    const obj = JSON.parse(decrypted.toString());
    res.send({ ...obj, fromBack: "Message decrypted successfully!" });
  } catch (err) {
    console.log(err.message);
  }
});

// Error Handler
app.use(function (err, req, res, next) {
  console.log(err.stack);
  res.status(500).send("Something broke!");
});

//create a server object:
app.listen(8081); //the server object listens on port 8081
